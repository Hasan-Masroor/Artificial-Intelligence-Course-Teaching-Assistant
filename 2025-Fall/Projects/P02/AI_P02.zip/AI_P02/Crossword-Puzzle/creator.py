import sys

from crossword import *


class Creator():

    def __init__(self, crossword, heuristic):
        '''
        initializes new crossword to inherit from crossword class
        also initializes domain for each variable
        '''
        self.crossword = crossword
        self.heuristic = heuristic
        self.domains = {}
        for var in self.crossword.variables:
            self.domains[var] = self.crossword.words.copy()


    def is_domain_consistent(self):
        """Enforce node consistency by removing words whose length != variable length."""
        # TODO: Implement node consistency check.
        raise NotImplementedError



    def revise(self, x, y):
        """Revise domain of x to enforce consistency with y.
        Remove any word from domain[x] that has no matching word in domain[y].
        """
        # TODO: Implement revise function from CSP algorithm
        raise NotImplementedError



    def pre_process_ac3(self):
        arcs = list()
        for x in self.domains:
            for y in self.crossword.neighbours(x):
                arcs.append((x, y))
        return arcs


    def ac3(self, arcs = None):
        """Implement AC-3 algorithm to enforce arc consistency.
        Should return True if successful; False if a domain becomes empty.
        """
        # TODO: Implement AC-3 algorithm.
        raise NotImplementedError



    def is_assign_consistent(self, assignment):
        used = set()
        for v in assignment:
            if assignment[v] not in used:
                used.add(assignment[v])
            else:
                return False
            for n in self.crossword.neighbours(v):
                if n in assignment:
                    i, j = self.crossword.overlaps[v, n]
                    if assignment[v][i] != assignment[n][j]: return False
        return True

    def is_solved(self, assignment):
        '''
        Helper function to show whether the crossword is complete 
        '''
        return not bool(self.crossword.variables - set(assignment))
    

    def select_unassigned_var(self, assignment, heuristic):
        """Select an unassigned variable using:
        - MRV (minimum remaining values)
        - If heuristic=True, combine with degree heuristic.
        """
        # TODO: Implement MRV (and optionally degree heuristic).
        raise NotImplementedError
    
    
    def order_domain_values(self, var, assignment):
        """Return domain values for `var` ordered by Least Constraining Value (LCV).

        The LCV heuristic prefers values that eliminate the fewest options
        for neighboring variables.
        """
        # TODO: Implement LCV heuristic.
        raise NotImplementedError


    def backtrack(self, assignment):
        """Implement recursive backtracking search.
        Should return a complete assignment if successful, else None.
        """
        # TODO: Implement backtracking algorithm with consistency checks.
        raise NotImplementedError
    
    
    def solve(self):
        """Solve the crossword CSP by enforcing consistency and using backtracking search."""
        self.is_domain_consistent()
        arcs = self.pre_process_ac3()
        self.ac3(arcs)
        return self.backtrack(dict())
